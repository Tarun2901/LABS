#!/bin/bash

# author : anirudh
# for TOKEN in  $@
# do
# 	echo $TOKEN
# done
arr=("anirudh goel" "" "c")
val=`expr 2 + 6 \* 2`

a="abc"
b="def"

if [ $a = $b ]
then
	echo "Equal"
else 
	echo "Not equal"
fi		


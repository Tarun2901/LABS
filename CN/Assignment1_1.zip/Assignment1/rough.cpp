#include<iostream>
using namespace std;

int main(){
	cout << "Executing the rough file";
	cout << "Waiting for user input ...";
	int x; cin >> x;
}
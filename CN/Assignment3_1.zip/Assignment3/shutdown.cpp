#include<stdlib.h>
#include<stdio.h>
const int size = 255;

int main(){
	// system("nmap -sP 192.168.1.* 1> livemachines.txt");
	
	// char* ipadd[size];
	// "nc 192.168.77.23 3000 < file_to_send"
	// "nc -l 3000 > file_to_receive"
	system("nc 192.168.75.47 3000");
	printf("hello");
	return 0;
}
